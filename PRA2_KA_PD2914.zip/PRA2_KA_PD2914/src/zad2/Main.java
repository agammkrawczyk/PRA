/**
 *
 *  @author KRAWCZYK AGNIESZKA PD2914
 *
 */

package zad2;


import javax.swing.*;
public class Main {

  public static void main(String[] args) {
	  
	
	
	      SwingUtilities.invokeLater(new Runnable() {
	          public void run() {
	              new ColorButton();
	          }
	      });
	  }
}  
	  
	 

